export class TodoModel{
    public id: number;
    public task : string;
    public category : string;
    public status : string;
    public assignDate : Date;
    public finishDate : Date;
}