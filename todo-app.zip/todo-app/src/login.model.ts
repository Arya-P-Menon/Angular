export class LoginModel {
    public email : string;
    public passwd : string;
}