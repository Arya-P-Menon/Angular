export class UserModel {
    public userid : number;
    public email : string;
    public passwd : string;
    public name : string;
}