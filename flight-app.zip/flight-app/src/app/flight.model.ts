export class Flight {
    public flightNo : number;
    public carrier : string;
    public source : string;
    public destiny : string;
}
