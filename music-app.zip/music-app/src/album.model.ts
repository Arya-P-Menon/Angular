export class AlbumModel {
    public title : string;
    public artist : string;
    public genre : string;
}
