export class LoginModel{
    public userid : string;
    public passwd : string;
    public role : string;
}