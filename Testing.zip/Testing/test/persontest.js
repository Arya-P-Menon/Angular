const assert = require('chai').assert;
const per = require('../person');

let p = new per.Person('Arya', 23);

describe('Person', () => {
    it("Person name should be Arya", () => {
        assert.equal(p.getName(),'Arya');
    });
    
    it("Person age should be above 21", () => {
        assert.isAbove(p.getAge(), 21);
    });
});