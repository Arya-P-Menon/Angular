const assert = require('chai').assert;
const ex2 = require('../example2');

describe('Example2', () => {

    describe('Hello', () => {
        it('Example2 sayHello should return Hello', () => {
            assert.equal(ex2.sayHello(), 'Hello');
        });
    
        it('Example2 sayhello should return type string', () => {
            assert.typeOf(ex2.sayHello(), 'string');
        });
    });
    

    it('Example2 sayBye should return GoodBye', () => {
        assert.equal(ex2.sayBye(), 'GoodBye');
    });

    it('Example2 sayBye should return type string', () => {
        assert.typeOf(ex2.sayBye(), 'string');
    });
});