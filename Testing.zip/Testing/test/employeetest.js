const assert = require('chai').assert;
const emp = require('../employee');

let e = new emp.Employee('Arya', 23, 30000);

describe('Employee', () => {
    it("Person name should be Arya", () => {
        assert.equal(e.getName(),'Arya');
    });
    
    it("Person age should be above 21", () => {
        assert.isAbove(e.getAge(), 21);
    });

    it("Person salary should be above 20000", () => {
        assert.isAbove(e.getSalary(), 20000);
    });
});