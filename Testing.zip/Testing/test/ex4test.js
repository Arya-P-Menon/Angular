const assert = require('chai').assert;
const ex4 = require('../example4');

describe('Example4', () => {
    describe('Add', () => {
        it('Example4 add should return above 10', () => {
            assert.isAbove(ex4.add(5,6),10);
        });

        it('Example4 add should return type number', () => {
            assert.typeOf(ex4.add(), 'number');
        });
    });

    describe('Sub', () => {
        it('Example4 sub should return above 10', () => {
            assert.isAbove(ex4.sub(95,6),10);
        });

        it('Example4 sub should return type number', () => {
            assert.typeOf(ex4.sub(), 'number');
        });
    });
});