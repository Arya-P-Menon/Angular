var add = (x, y) => x + y;

var sub = (x, y) => x - y;

module.exports = { add, sub}