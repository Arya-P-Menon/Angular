function greeting() {
    console.log('Greetings from Nodejs');
}

greeting();