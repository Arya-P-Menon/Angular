const ex2 = require('./example2');

//console.log(sayHello());

console.log(ex2.sayHello());
console.log(ex2.sayBye());