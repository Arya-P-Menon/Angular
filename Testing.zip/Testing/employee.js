const Person = require('./person').Person

class Employee extends Person {
    constructor(name, age, salary){
        super(name,age);
        this.salary = salary;
    }

    getSalary = () => this.salary;
}

module.exports = { Employee }

// let e = new Employee('Arya', 23, 30000);
// console.log(e.getName() + '\t' + e.getSalary());