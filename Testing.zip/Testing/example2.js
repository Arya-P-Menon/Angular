//function sayHello(){
 //   return 'Hello';
//}

// sayHello = function() {
  //  return 'Hello';
//}

sayHello = () => "Hello";

sayBye = () => "GoodBye";

//console.log(sayHello());

//module.exports = sayHello();

module.exports = { sayHello, sayBye };